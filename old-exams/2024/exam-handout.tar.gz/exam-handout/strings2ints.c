#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "util.h"

int main(int argc, char** argv) {
  if (argc != 4) {
    fprintf(stderr, "Usage: %s MAPPINGFILE STRINGSFILE INTSFILE\n", argv[0]);
    exit(1);
  }

  assert(0); // TODO
}
