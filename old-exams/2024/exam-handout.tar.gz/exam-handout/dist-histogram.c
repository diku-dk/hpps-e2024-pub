#include "dist-histogram.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <omp.h>

// Euclidean distance.
static double dist(double ax, double ay, double bx, double by) {
  double dx = ax - bx;
  double dy = ay - by;

  return sqrt(dx*dx + dy*dy);
}

static void histogram_sequential(int k, int n, int32_t *H, double *points) {
  // Sequentially compute k-bin distance histogram.
  //
  // You may assume that H is already zero-initialised.

  assert(0); // TODO
}

static void histogram_parallel(int k, int n, int32_t *H, double *points) {
  // Compute k-bin distance histogram in parallel.
  //
  // You may assume that H is already zero-initialised.
  //
  // You may parallelise this function however you wish - we suggest
  // picking the strategy that worked the best for your counting
  // histograms.

  assert(0); // TODO
}

struct algorithm algorithms[] = {
  { .name = "sequential", .f = &histogram_sequential
  },
  { .name = "parallel", .f = &histogram_parallel
  }
};

const int num_algorithms = sizeof(algorithms) / sizeof(algorithms[0]);
