#include "histogram.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <omp.h>

static void histogram_sequential(int k, int n, int32_t *H, int32_t *samples) {
  // Sequentially compute k-bin counting histogram, stored in the
  // k-element array H. You may assume that H is already
  // zero-initialised.

  assert(0); // TODO
}

static void histogram_parallel_bins(int k, int n, int32_t *H, int32_t *samples) {
  // Compute k-bin counting histogram in parallel.
  //
  // You may assume that H is already zero-initialised.
  //
  // This function must conceptually divide the array H among the
  // threads, such that only one thread is responsible for updating
  // (or otherwise accessing) any specific element of 'H' (however one
  // thread may still be responsible for several elements of H).

  assert(0); // TODO
}

static void histogram_parallel_samples(int k, int n, int32_t *H, int32_t *samples) {
  // Compute k-bin counting histogram in parallel.
  //
  // You may assume that H is already zero-initialised.
  //
  // This function must divide the 'samples' array among the threads,
  // with each thread creating and updating a local complete k-bin
  // histogram for its corresponding chunk, all of which are then
  // added to 'H' at the end.

  assert(0); // TODO
}

struct algorithm algorithms[] = {
  { .name = "sequential", .f = &histogram_sequential
  },
  { .name = "parallel_bins", .f = &histogram_parallel_bins
  },
  { .name = "parallel_samples", .f = &histogram_parallel_samples
  }
};

const int num_algorithms = sizeof(algorithms) / sizeof(algorithms[0]);
