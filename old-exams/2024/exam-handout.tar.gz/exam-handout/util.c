#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <sys/time.h>

double seconds(void) {
  struct timeval tv;
  gettimeofday(&tv, NULL); // The NULL is for timezone information.
  return tv.tv_sec + tv.tv_usec/1000000.0;
}

int32_t* read_ints(const char* fname, int32_t* n) {
  FILE *f = fopen(fname, "r");
  assert(f != NULL);

  assert(fread(n, sizeof(int32_t), 1, f) == 1);

  int* p = calloc(*n, sizeof(int32_t));

  assert((int)fread(p, sizeof(int32_t), *n, f) == *n);

  fclose(f);

  return p;
}

void write_ints(const char* fname, int32_t n, int32_t* p) {
  FILE *f = fopen(fname, "w");
  assert(f != NULL);

  assert(fwrite(&n, sizeof(int32_t), 1, f) == 1);
  assert((int)fwrite(p, sizeof(int32_t), n, f) == n);

  fclose(f);
}

double* read_points(const char* fname, int* n) {
  assert(0); // TODO
}

void write_points(const char* fname, int n, double* p) {
  assert(0); // TODO
}

char** read_lines(const char* fname, int* n) {
  assert(0); // TODO
}
