#include "dist-histogram.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <omp.h>

// Euclidean distance.
static double dist(double ax, double ay, double bx, double by) {
  double dx = ax - bx;
  double dy = ay - by;

  return sqrt(dx*dx + dy*dy);
}

static void histogram_sequential(int k, int n, int32_t *H, double *points) {
  for (int i = 0; i < n; i++) {
    double ax = points[i*2+0];
    double ay = points[i*2+1];
    for (int j = 0; j < n; j++) {
      if (i == j) {
        continue;
      }
      double bx = points[j*2+0];
      double by = points[j*2+1];
      int d = dist(ax, ay, bx, by);
      if (d < k) {
        H[d]++;
      }
    }
  }
}

static void histogram_parallel(int k, int n, int32_t *H, double *points) {
  int P = omp_get_max_threads();

  #pragma omp parallel
  {
    int t = omp_get_thread_num();

    int chunk_size = n / P;
    int start = t * chunk_size;
    int end = start + chunk_size;
    if (t == omp_get_num_threads()-1) {
      end = n;
    }

    int32_t *H_local = calloc(k, sizeof(int32_t));

    for (int i = start; i < end; i++) {
      double ax = points[i*2+0];
      double ay = points[i*2+1];
      for (int j = 0; j < n; j++) {
        if (i == j) {
          continue;
        }
        double bx = points[j*2+0];
        double by = points[j*2+1];
        int d = dist(ax, ay, bx, by);

        if (d < k) {
          H_local[d]++;
        }
      }
    }

    #pragma omp critical
    {
      for (int i = 0; i < k; i++) {
        H[i] += H_local[i];
      }
    }
    free(H_local);
  }
}

struct algorithm algorithms[] = {
  { .name = "sequential", .f = &histogram_sequential
  },
  { .name = "parallel", .f = &histogram_parallel
  }
};

const int num_algorithms = sizeof(algorithms) / sizeof(algorithms[0]);
