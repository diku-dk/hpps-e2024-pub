#!/bin/sh

WHITE=$(printf '\033[1;37m')
NC=$(printf '\033[0m')
info() {
    printf "\n${WHITE}$*${NC}\n"
}

calc() {
    echo "scale=10; $*" | bc
}

mkdir -p data

info "# Compiling."
make -Bj

mk_ints() {
    n=$1
    k=$2
    s=$3
    outfile="data/n${n}_k${k}_s${s}.ints"

    if ! [ -f "$outfile" ]; then
        info "### Generating $outfile..." >&2
        "./gen-ints" "${n}" "${k}" "${s}" "$outfile" > /dev/null
    fi
    echo "$outfile"
}

mk_points() {
    n=$1
    s=$2
    outfile="data/n${n}_s${s}.points"

    if ! [ -f "$outfile" ]; then
        info "### Generating $outfile..." >&2
        "./gen-points" "${n}" "${s}" "$outfile" > /dev/null
    fi
    echo "$outfile"
}

THREADS="1 2 4 8"
RUNS=10

bench_histogram() {
    OMP_NUM_THREADS=$1 ./run-histogram ${RUNS} ${2} ${3} $(mk_ints ${4} ${3} 1) /dev/null | awk '/^Mean runtime/ { print $6 }'
}

bench_dist_histogram() {
    OMP_NUM_THREADS=$1 ./run-dist-histogram ${RUNS} ${2} ${3} $(mk_points ${4} ${5}) /dev/null | awk '/^Mean runtime/ { print $6 }'
}


hist_strong_scaling() {
    n=$1
    k=$2
    algorithm=$3
    info "# Counting histogram, strong scaling, n=${n}, k=${k}, ${algorithm}"

    baseline=$(bench_histogram 1 sequential $k $n)

    printf "Baseline: %.3fs\n" $baseline

    for t in $THREADS; do
        printf "%d threads: " ${t}
        runtime=$(bench_histogram $t $algorithm $k $n)
        speedup=$(calc "$baseline/$runtime")
        printf "%.2fx\n" $speedup
    done
}

hist_weak_scaling() {
    n=$1
    k=$2
    algorithm=$3
    info "# Counting histogram, weak scaling, n=${n}, k=${k}, ${algorithm}"

    for t in $THREADS; do
        printf "%d threads: " ${t}
        baseline=$(bench_histogram 1 sequential $k $(calc "${n}*${t}"))
        runtime=$(bench_histogram $t $algorithm $k $(calc "${n}*${t}"))
        speedup=$(calc "$baseline/$runtime")
        printf "%.2fx\n" $speedup
    done
}

dist_strong_scaling() {
    n=$1
    k=$2
    s=$3
    algorithm=$4
    info "# Distance histogram, strong scaling, n=${n}, k=${k}, s=${s}, ${algorithm}"

    baseline=$(bench_dist_histogram 1 sequential $k $n $s)

    printf "Baseline: %.3fs\n" $baseline

    for t in $THREADS; do
        printf "%d threads: " ${t}
        runtime=$(bench_dist_histogram $t $algorithm $k $n $s)
        speedup=$(calc "$baseline/$runtime")
        printf "%.3fs (%.2fx)\n" $runtime $speedup
    done
}

dist_weak_scaling() {
    n=$1
    k=$2
    s=$3
    algorithm=$4
    info "# Distance histogram, weak scaling, n=${n}, k=${k}, s=${s}, ${algorithm}"

    for t in $THREADS; do
        printf "%d threads: " ${t}
        n2=$(calc "sqrt($t) * $n")
        baseline=$(bench_dist_histogram 1 sequential $k $n2 $s)
        runtime=$(bench_dist_histogram $t $algorithm $k $n2 $s)
        speedup=$(calc "$baseline/$runtime")
        printf "%.3fs (%.2fx)\n" $runtime $speedup
    done
}


hist_strong_scaling 10000000 100 parallel_bins
hist_strong_scaling 10000000 100 parallel_samples

hist_strong_scaling 10000000 1000 parallel_bins
hist_strong_scaling 10000000 1000 parallel_samples

hist_strong_scaling 10000000 10000 parallel_bins
hist_strong_scaling 10000000 10000 parallel_samples

hist_weak_scaling 1000000 100 parallel_bins
hist_weak_scaling 1000000 100 parallel_samples

dist_strong_scaling 10000 100     1 parallel
dist_strong_scaling 10000 1000   10 parallel
dist_strong_scaling 10000 10000 100 parallel

dist_weak_scaling 2000 100 1 parallel
