#!/bin/sh

set -e

ns="100000000"
ks="100000"
strides="1 16 32 64"
algorithms="sequential parallel_bins parallel_samples"

RUNS=4

mkdir -p data

for n in $ns; do
    for k in $ks; do
        for s in $strides; do
            base="data/s${s}_k${k}_n${n}"
            input="$base.ints"
            reference="$base.reference"
            if ! [ -f "$input" ]; then
                echo "Generating ${input}."
                ./gen-ints ${n} ${k} ${s} "$input"
            fi

            if ! [ -f "$reference" ]; then
                echo "Generating reference result."
                ./run-histogram 1 sequential "$k" "$input" "$reference"
            fi

            for A in $algorithms; do
                echo
                printf "s=${s} "
                ./run-histogram "${RUNS}" "${A}" "$k" "$input" "${input}.${A}"
                if ! cmp "$reference" "${input}.${A}"; then
                    echo "BAD!"
                fi
            done
        done
    done
done
