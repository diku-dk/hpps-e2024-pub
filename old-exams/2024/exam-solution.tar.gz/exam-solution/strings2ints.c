#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "util.h"

struct mapping {
  int id;
  char *string;
};

struct mapping* read_mapping_file(const char *fname, int *n) {
  FILE *f = fopen(fname, "r");
  assert(f != NULL);

  int capacity = 10;
  int i = 0;
  struct mapping *mappings = calloc(capacity, sizeof(struct mapping));

  while (1) {
    int32_t len;
    if (fread(&len, sizeof(int32_t), 1, f) == 0) {
      break;
    }

    if (i == capacity) {
      capacity *= 2;
      mappings = realloc(mappings, capacity * sizeof(struct mapping));
    }

    mappings[i].string = malloc(len + 1);
    assert(fread(mappings[i].string, 1, len, f) == (size_t)len);
    mappings[i].string[len] = 0;
    assert(fread(&mappings[i].id, sizeof(int32_t), 1, f) == 1);
    i++;
  }

  fclose(f);
  *n = i;
  return mappings;
}

int main(int argc, char** argv) {
  if (argc != 4) {
    fprintf(stderr, "Usage: %s MAPPINGFILE STRINGSFILE INTSFILE\n", argv[0]);
    exit(1);
  }

  int num_mappings;
  struct mapping *mappings = read_mapping_file(argv[1], &num_mappings);

  int num_lines;
  char **lines = read_lines(argv[2], &num_lines);

  FILE *intsf = fopen(argv[3], "w");
  assert(intsf != NULL);

  fwrite(&num_lines, sizeof(int32_t), 1, intsf);
  for (int i = 0; i < num_lines; i++) {
    int found = 0;
    for (int j = 0; j < num_mappings; j++) {
      if (strcmp(mappings[j].string, lines[i]) == 0) {
        found = 1;
        assert(fwrite(&mappings[j].id, sizeof(int), 1, intsf) == 1);
        break;
      }
    }
    if (!found) {
      fprintf(stderr, "Line not in mapping: %s\n", lines[i]);
      exit(1);
    }
    free(lines[i]);
  }
  free(lines);

  for (int i = 0; i < num_mappings; i++) {
    free(mappings[i].string);
  }
  free(mappings);

  fclose(intsf);
}
