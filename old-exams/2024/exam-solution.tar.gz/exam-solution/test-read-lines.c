// Simple test program for read_lines(). Just prints the lines to stdout.

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "util.h"

int main(int argc, char* argv[]) {
  assert(argc == 2);

  int num_lines;
  char **lines = read_lines(argv[1], &num_lines);

  for (int i = 0; i < num_lines; i++) {
    puts(lines[i]);
    free(lines[i]);
  }

  free(lines);
}
