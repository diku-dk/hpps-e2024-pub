#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <sys/time.h>

double seconds(void) {
  struct timeval tv;
  gettimeofday(&tv, NULL); // The NULL is for timezone information.
  return tv.tv_sec + tv.tv_usec/1000000.0;
}

int32_t* read_ints(const char* fname, int32_t* n) {
  FILE *f = fopen(fname, "r");
  assert(f != NULL);

  assert(fread(n, sizeof(int32_t), 1, f) == 1);

  int* p = calloc(*n, sizeof(int32_t));

  assert((int)fread(p, sizeof(int32_t), *n, f) == *n);

  fclose(f);

  return p;
}

void write_ints(const char* fname, int32_t n, int32_t* p) {
  FILE *f = fopen(fname, "w");
  assert(f != NULL);

  assert(fwrite(&n, sizeof(int32_t), 1, f) == 1);
  assert((int)fwrite(p, sizeof(int32_t), n, f) == n);

  fclose(f);
}

double* read_points(const char* fname, int* n) {
  FILE *f = fopen(fname, "r");
  assert(f != NULL);

  assert(fread(n, sizeof(int32_t), 1, f) == 1);

  double* p = calloc(*n*2, sizeof(double));

  assert((int)fread(p, sizeof(double), *n*2, f) == *n*2);

  fclose(f);

  return p;
}

void write_points(const char* fname, int n, double* p) {
  FILE *f = fopen(fname, "w");
  assert(f != NULL);

  assert(fwrite(&n, sizeof(int32_t), 1, f) == 1);
  assert((int)fwrite(p, sizeof(double), n*2, f) == n*2);

  fclose(f);
}

char** read_lines(const char* fname, int* n) {
  FILE *f = fopen(fname, "r");
  assert(f != NULL);

  char *line = NULL;
  size_t bufsize;
  ssize_t len;

  int capacity = 10;
  int i = 0;
  char** lines = calloc(capacity, sizeof(char*));

  while ((len = getline(&line, &bufsize, f)) != -1) {
    if (i == capacity) {
      capacity *= 2;
      lines = realloc(lines, capacity * sizeof(char*));
    }
    assert(line[len-1] == '\n');
    line[len-1] = 0;
    lines[i++] = strdup(line);
  }
  free(line);

  fclose(f);

  *n = i;
  return lines;
}
