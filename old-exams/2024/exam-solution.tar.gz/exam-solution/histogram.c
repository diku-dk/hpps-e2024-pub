#include "histogram.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <omp.h>

void histogram_sequential(int k, int n, int32_t *H, int32_t *samples) {
  for (int i = 0; i < n; i++) {
    int j = samples[i];
    if (j >= 0 && j < k) {
      H[j]++;
    }
  }
}

void histogram_parallel_bins(int k, int n, int32_t *H, int32_t *samples) {
  int P = omp_get_max_threads();
  int bucket_size = (k + P - 1) / P;

  #pragma omp parallel for
  for (int p = 0; p < P; p++) {
    for (int i = 0; i < n; i++) {
      int j = samples[i];
      if (j >= p*bucket_size && j < (p+1)*bucket_size && j < k) {
        H[j]++;
      }
    }
  }
}

void histogram_parallel_samples(int k, int n, int32_t *H, int32_t *samples) {
  int P = omp_get_max_threads();

  #pragma omp parallel
  {
    int t = omp_get_thread_num();

    int chunk_size = n / P;
    int start = t * chunk_size;
    int end = start + chunk_size;
    if (t == omp_get_num_threads()-1) {
      end = n;
    }

    int32_t *H_local = calloc(k, sizeof(int32_t));

    for (int i = start; i < end; i++) {
      int j = samples[i];
      if (j >= 0 && j < k) {
        H_local[j]++;
      }
    }

    #pragma omp critical
    {
      for (int i = 0; i < k; i++) {
        H[i] += H_local[i];
      }
    }
    free(H_local);
  }
}

struct algorithm algorithms[] = {
  { .name = "sequential", .f = &histogram_sequential
  },
  { .name = "parallel_bins", .f = &histogram_parallel_bins
  },
  { .name = "parallel_samples", .f = &histogram_parallel_samples
  }
};

const int num_algorithms = sizeof(algorithms) / sizeof(algorithms[0]);
