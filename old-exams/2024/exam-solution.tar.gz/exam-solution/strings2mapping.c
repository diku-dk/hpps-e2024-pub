#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "util.h"

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: %s STRINGSFILE MAPPINGFILE\n", argv[0]);
    exit(1);
  }

  int num_lines;
  char **lines = read_lines(argv[1], &num_lines);

  FILE *f = fopen(argv[2], "w");
  assert(f != NULL);

  int counter = 0;

  for (int i = 0; i < num_lines; i++) {
    int j;
    for (j = 0; j <= i; j++) {
      if (strcmp(lines[i], lines[j]) == 0) {
        break;
      }
    }
    if (j == i) {
      int32_t len = strlen(lines[i]);
      assert(fwrite(&len, sizeof(int32_t), 1, f) == 1);
      assert(fwrite(lines[i], 1, len, f) == (size_t)len);
      assert(fwrite(&counter, sizeof(int32_t), 1, f) == 1);
      counter++;
    }
  }
  fclose(f);

  for (int i = 0; i < num_lines; i++) {
    free(lines[i]);
  }
  free(lines);
}
